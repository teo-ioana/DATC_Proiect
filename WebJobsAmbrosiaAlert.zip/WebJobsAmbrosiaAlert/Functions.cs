﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.IO;

namespace WebJobsAmbrosiaAlert
{
    public class Functions
    {
        public static void ProcessQueueMessage(
            [QueueTrigger("alerteplante")] string message,
            [Blob("alerteplante/{queueTrigger}", FileAccess.Read)] Stream myBlob,
            [Blob("alerteplante/alerta-{queueTrigger}", FileAccess.Write)] Stream outputBlob,
            ILogger log)
        {
            log.LogInformation($"BlobInput processed blob\n Name:{message} \n Size: {myBlob.Length} bytes");
            myBlob.CopyTo(outputBlob);
        }
    }
}